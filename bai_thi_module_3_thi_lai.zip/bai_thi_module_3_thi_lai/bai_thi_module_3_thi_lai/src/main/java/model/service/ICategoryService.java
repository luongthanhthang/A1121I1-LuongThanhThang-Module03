package model.service;

import model.bean.Category;

import java.util.List;

public interface ICategoryService {
    List<Category> findAll();
}
