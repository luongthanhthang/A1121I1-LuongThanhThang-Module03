package model.repository;

import model.bean.Category;

import java.util.List;

public interface ICategoryRepository {
    List<Category> findAll();
}
